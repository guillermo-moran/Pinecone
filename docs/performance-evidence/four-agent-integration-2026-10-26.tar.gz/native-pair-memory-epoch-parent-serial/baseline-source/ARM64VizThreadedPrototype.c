#include "ARM64VizThreadedPrototype.h"

#ifndef AVZ_THREADED_PROTOTYPE_ENABLE
#define AVZ_THREADED_PROTOTYPE_ENABLE 0
#endif

#if AVZ_THREADED_PROTOTYPE_ENABLE
#ifndef AVZ_THREADED_PROTOTYPE_HAS_MUSTTAIL
#if defined(__clang__) && defined(__has_attribute)
#define AVZ_THREADED_PROTOTYPE_HAS_MUSTTAIL __has_attribute(musttail)
#else
#define AVZ_THREADED_PROTOTYPE_HAS_MUSTTAIL 0
#endif
#endif
#if !AVZ_THREADED_PROTOTYPE_HAS_MUSTTAIL
#error "threaded prototype requires compiler-enforced musttail; no fallback"
#endif

#include <stdlib.h>
#include <string.h>

typedef struct TPOperation TPOperation;
typedef struct {
    AVZNativeCPU *cpu;
    uint64_t remaining;
    AVZNativeBlockResult result;
} TPExecution;
typedef void (*TPHandler)(TPExecution *, const TPOperation *);

struct TPOperation {
    TPHandler handler;
    const TPOperation *next;
    const TPOperation *taken;
    uint64_t next_pc;
    uint64_t target_pc;
    uint64_t immediate;
    uint64_t mask;
    uint32_t raw;
    uint16_t source;
    uint16_t destination;
    uint16_t conditions;
};

struct AVZThreadedPrototype {
    uint64_t base_pc;
    size_t count;
    TPOperation operations[];
};

/* Register offsets are specialized at preparation, including SP versus XZR.
 * memcpy avoids aliasing and subobject pointer arithmetic assumptions. */
static inline uint64_t tp_read(const AVZNativeCPU *cpu, uint16_t offset)
{
    uint64_t value = 0;
    if (offset != UINT16_MAX)
        memcpy(&value, (const unsigned char *)cpu + offset, sizeof(value));
    return value;
}

static inline void tp_write(AVZNativeCPU *cpu, uint16_t offset, uint64_t value)
{
    if (offset != UINT16_MAX)
        memcpy((unsigned char *)cpu + offset, &value, sizeof(value));
}

#define TP_HANDLER(name) \
    static __attribute__((noinline)) void name(TPExecution *execution, const TPOperation *op)

/* Each handler commits one complete instruction before dispatch. There is no
 * central switch or shared dispatch loop. musttail enforces identical ABI and
 * bounded stack even at -O0 / -fno-optimize-sibling-calls. */
#define TP_NEXT(next_operation) do { \
    const TPOperation *next = (next_operation); \
    execution->result.steps++; \
    if (--execution->remaining == 0) { \
        execution->result.status = AVZ_NATIVE_STATUS_MAX_STEPS; \
        return; \
    } \
    __attribute__((musttail)) return next->handler(execution, next); \
} while (0)

TP_HANDLER(tp_outside)
{
    (void)op;
    execution->result.status = AVZ_NATIVE_STATUS_OUTSIDE_BLOCK;
}

TP_HANDLER(tp_unsupported)
{
    execution->result.status = AVZ_NATIVE_STATUS_UNSUPPORTED;
    execution->result.unsupported_instruction = op->raw;
}

TP_HANDLER(tp_nop)
{
    execution->cpu->pc = op->next_pc;
    TP_NEXT(op->next);
}

#define TP_ALU(name, type, bits, subtract, flags) \
    TP_HANDLER(name) { \
        AVZNativeCPU *cpu = execution->cpu; \
        uint64_t a = (type)tp_read(cpu, op->source); \
        uint64_t b = op->immediate; \
        uint64_t value = (type)((subtract) ? a - b : a + b); \
        if (flags) { \
            uint64_t n = value >> ((bits) - 1); \
            uint64_t z = value == 0; \
            uint64_t c = (subtract) ? a >= b : value < a; \
            uint64_t v = (((subtract) ? (a ^ b) : ~(a ^ b)) & \
                           (a ^ value)) >> ((bits) - 1); \
            cpu->pstate = (cpu->pstate & ~UINT64_C(0xf0000000)) | \
                (n << 31) | (z << 30) | (c << 29) | ((v & 1) << 28); \
        } \
        tp_write(cpu, op->destination, value); \
        cpu->pc = op->next_pc; \
        TP_NEXT(op->next); \
    }

TP_ALU(tp_add32, uint32_t, 32, 0, 0)
TP_ALU(tp_sub32, uint32_t, 32, 1, 0)
TP_ALU(tp_adds32, uint32_t, 32, 0, 1)
TP_ALU(tp_subs32, uint32_t, 32, 1, 1)
TP_ALU(tp_add64, uint64_t, 64, 0, 0)
TP_ALU(tp_sub64, uint64_t, 64, 1, 0)
TP_ALU(tp_adds64, uint64_t, 64, 0, 1)
TP_ALU(tp_subs64, uint64_t, 64, 1, 1)

TP_HANDLER(tp_move)
{
    tp_write(execution->cpu, op->destination, op->immediate);
    execution->cpu->pc = op->next_pc;
    TP_NEXT(op->next);
}

TP_HANDLER(tp_movk)
{
    tp_write(execution->cpu, op->destination,
        (tp_read(execution->cpu, op->destination) & op->mask) | op->immediate);
    execution->cpu->pc = op->next_pc;
    TP_NEXT(op->next);
}

TP_HANDLER(tp_branch)
{
    execution->cpu->pc = op->target_pc;
    TP_NEXT(op->taken);
}

TP_HANDLER(tp_link)
{
    execution->cpu->x[30] = op->next_pc;
    execution->cpu->pc = op->target_pc;
    TP_NEXT(op->taken);
}

TP_HANDLER(tp_bcond)
{
    unsigned nzcv = (unsigned)((execution->cpu->pstate >> 28) & 15);
    int taken = (op->conditions >> nzcv) & 1;
    execution->cpu->pc = taken ? op->target_pc : op->next_pc;
    TP_NEXT(taken ? op->taken : op->next);
}

#define TP_TEST_BRANCH(name, nonzero) \
    TP_HANDLER(name) { \
        uint64_t value = tp_read(execution->cpu, op->source) & op->mask; \
        int taken = (value != 0) == (nonzero); \
        execution->cpu->pc = taken ? op->target_pc : op->next_pc; \
        TP_NEXT(taken ? op->taken : op->next); \
    }
TP_TEST_BRANCH(tp_zero, 0)
TP_TEST_BRANCH(tp_nonzero, 1)

static uint16_t tp_register(unsigned reg, int sp)
{
    _Static_assert(sizeof(AVZNativeCPU) < UINT16_MAX, "register offset fits");
    if (reg == 31) return sp ? (uint16_t)offsetof(AVZNativeCPU, sp) : UINT16_MAX;
    return (uint16_t)(offsetof(AVZNativeCPU, x) + reg * sizeof(uint64_t));
}

static uint16_t tp_conditions(unsigned condition)
{
    uint16_t table = 0;
    for (unsigned flags = 0; flags < 16; flags++) {
        int n = (flags >> 3) & 1, z = (flags >> 2) & 1;
        int c = (flags >> 1) & 1, v = flags & 1;
        const int matches[] = {z, c, n, v, c && !z, n == v, !z && n == v, 1};
        int match = matches[condition >> 1];
        if ((condition & 1) && condition != 15) match = !match;
        table |= (uint16_t)(match << flags);
    }
    return table;
}

static const TPOperation *tp_lookup(const AVZThreadedPrototype *program, uint64_t pc)
{
    uint64_t delta = pc - program->base_pc;
    if (pc < program->base_pc || (delta & 3) || delta / 4 >= program->count)
        return &program->operations[program->count];
    return &program->operations[delta / 4];
}

int avz_tp_available(void) { return 1; }

int avz_tp_supports_instruction(const AVZNativeInstruction *instruction)
{
    if (!instruction) return 0;
    switch (instruction->kind) {
    case AVZ_NATIVE_OP_NOP:
        return instruction->raw == UINT32_C(0xd503201f);
    case AVZ_NATIVE_OP_ADD_SUB_IMMEDIATE:
        return !(instruction->raw & UINT32_C(0x00800000));
    case AVZ_NATIVE_OP_MOVE_WIDE:
    case AVZ_NATIVE_OP_ADR:
    case AVZ_NATIVE_OP_BRANCH:
    case AVZ_NATIVE_OP_BCOND:
    case AVZ_NATIVE_OP_CBZ:
    case AVZ_NATIVE_OP_TBZ:
        return 1;
    default:
        return 0;
    }
}

AVZThreadedPrototype *avz_tp_create(const uint32_t *words, size_t count, uint64_t base_pc)
{
    if (!words || !count || count > AVZ_TP_MAX_INSTRUCTIONS || (base_pc & 3) ||
        count - 1 > (UINT64_MAX - base_pc) / 4) return NULL;
    AVZThreadedPrototype *program = calloc(1, sizeof(*program) +
        (count + 1) * sizeof(TPOperation));
    if (!program) return NULL;
    program->base_pc = base_pc;
    program->count = count;
    program->operations[count].handler = tp_outside;
    for (size_t i = 0; i < count; i++) {
        TPOperation *op = &program->operations[i];
        AVZNativeInstruction decoded;
        uint64_t pc = base_pc + i * 4;
        op->handler = tp_unsupported;
        op->raw = words[i];
        op->next = &program->operations[i + 1];
        op->next_pc = pc + 4;
        if (!avz_native_decode_instruction(words[i], &decoded) ||
            !avz_tp_supports_instruction(&decoded)) continue;
        op->immediate = (uint64_t)decoded.immediate;
        op->target_pc = pc + op->immediate;
        op->taken = tp_lookup(program, op->target_pc);
        op->destination = tp_register(decoded.rd, 0);
        switch (decoded.kind) {
        case AVZ_NATIVE_OP_NOP:
            /* Do not claim other hints, waits or synchronization instructions. */
            if (words[i] == UINT32_C(0xd503201f)) op->handler = tp_nop;
            break;
        case AVZ_NATIVE_OP_ADD_SUB_IMMEDIATE: {
            /* The reference decoder also accepts reserved bit 23; we do not. */
            if (words[i] & UINT32_C(0x00800000)) break;
            static const TPHandler handlers[] = {
                tp_add32, tp_sub32, tp_adds32, tp_subs32,
                tp_add64, tp_sub64, tp_adds64, tp_subs64
            };
            op->handler = handlers[(decoded.bits == 64 ? 4 : 0) + decoded.flags];
            op->source = tp_register(decoded.rn, 1);
            op->destination = tp_register(decoded.rd, !(decoded.flags & 2));
            break;
        }
        case AVZ_NATIVE_OP_MOVE_WIDE: {
            uint64_t mask = decoded.bits == 64 ? UINT64_MAX : UINT32_MAX;
            op->mask = mask & ~(UINT64_C(0xffff) << decoded.shift_amount);
            if (decoded.flags == 0) op->immediate = ~op->immediate;
            op->immediate &= mask;
            op->handler = decoded.flags == 3 ? tp_movk : tp_move;
            break;
        }
        case AVZ_NATIVE_OP_ADR:
            op->immediate += (decoded.flags & 1) ? pc & ~UINT64_C(4095) : pc;
            op->handler = tp_move;
            break;
        case AVZ_NATIVE_OP_BRANCH:
            op->handler = (decoded.flags & 1) ? tp_link : tp_branch;
            break;
        case AVZ_NATIVE_OP_BCOND:
            op->conditions = tp_conditions(decoded.condition);
            op->handler = tp_bcond;
            break;
        case AVZ_NATIVE_OP_CBZ:
        case AVZ_NATIVE_OP_TBZ:
            op->source = tp_register(decoded.rt, 0);
            op->mask = decoded.kind == AVZ_NATIVE_OP_TBZ
                ? UINT64_C(1) << decoded.shift_amount
                : decoded.bits == 64 ? UINT64_MAX : UINT32_MAX;
            op->handler = (decoded.flags & 1) ? tp_nonzero : tp_zero;
            break;
        default:
            break;
        }
    }
    return program;
}

void avz_tp_destroy(AVZThreadedPrototype *program) { free(program); }

size_t avz_tp_program_bytes(const AVZThreadedPrototype *program)
{
    return program ? sizeof(*program) + (program->count + 1) * sizeof(TPOperation) : 0;
}

AVZNativeBlockResult avz_tp_run(const AVZThreadedPrototype *program,
                              uint64_t max_steps, AVZNativeCPU *cpu)
{
    TPExecution execution = {.cpu = cpu, .remaining = max_steps};
    if (!program || !cpu) execution.result.status = AVZ_TP_STATUS_INVALID_ARGUMENT;
    else if (!max_steps) execution.result.status = AVZ_NATIVE_STATUS_MAX_STEPS;
    else if (cpu->halted) execution.result.status = AVZ_NATIVE_STATUS_HALTED;
    else {
        const TPOperation *op = tp_lookup(program, cpu->pc);
        op->handler(&execution, op);
    }
    execution.result.generic_dispatches = execution.result.steps;
    return execution.result;
}

#else

int avz_tp_available(void) { return 0; }
int avz_tp_supports_instruction(const AVZNativeInstruction *instruction)
{
    (void)instruction;
    return 0;
}
AVZThreadedPrototype *avz_tp_create(const uint32_t *words, size_t count, uint64_t base_pc)
{
    (void)words; (void)count; (void)base_pc;
    return NULL;
}
void avz_tp_destroy(AVZThreadedPrototype *program) { (void)program; }
size_t avz_tp_program_bytes(const AVZThreadedPrototype *program)
{
    (void)program;
    return 0;
}
AVZNativeBlockResult avz_tp_run(const AVZThreadedPrototype *program,
                              uint64_t max_steps, AVZNativeCPU *cpu)
{
    (void)program; (void)max_steps; (void)cpu;
    return (AVZNativeBlockResult){.status = AVZ_TP_STATUS_DISABLED};
}

#endif
