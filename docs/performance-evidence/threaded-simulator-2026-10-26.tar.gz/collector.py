import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

ROOT = Path('/Users/gmoran/Documents/Projects/arm64viz')
OUT = Path('/tmp/pinecone-threaded-ab-controlled-20261026')
OUT.mkdir(exist_ok=False)
DEVICE = '541E22EE-C52B-4478-A041-56FEDC23ACFF'
BUNDLE = 'me.gmoran.pinecone'
container = Path(subprocess.check_output(['xcrun', 'simctl', 'get_app_container', DEVICE, BUNDLE, 'data'], text=True).strip())
cache = container / 'Library/Caches'
disk = container / 'Library/Application Support/Pinecone/rootfs.ext4'

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

def processes():
    rows = subprocess.check_output(['ps', '-axo', 'pid=,time=,rss=,comm='], text=True)
    found = []
    for row in rows.splitlines():
        parts = row.split(None, 3)
        if len(parts) != 4 or not parts[3].endswith('/Pinecone.app/Pinecone'):
            continue
        units = parts[1].split(':')
        seconds = sum(float(v) * 60 ** i for i, v in enumerate(reversed(units)))
        found.append({'pid': int(parts[0]), 'cpuSeconds': seconds, 'rssKiB': int(parts[2])})
    return found

subprocess.run(['xcrun', 'simctl', 'terminate', DEVICE, BUNDLE], check=False, capture_output=True)
baseline_disk = OUT / 'baseline-rootfs.ext4'
subprocess.run(['cp', '-c', str(disk), str(baseline_disk)], check=True)
identity = {'diskSHA256': digest(baseline_disk), 'order': [0, 1, 1, 0, 0, 1],
            'device': DEVICE, 'vcpuCount': 2, 'interactionTrace': 1,
            'imageState': 'persisted_user_state',
            'appSHA256': digest(Path('/tmp/arm64viz-nine-derived/Build/Products/Release-iphonesimulator/Pinecone.app/Pinecone'))}
(OUT / 'identity.json').write_text(json.dumps(identity, indent=2))
results = []
for number, enabled in enumerate(identity['order'], 1):
    subprocess.run(['xcrun', 'simctl', 'terminate', DEVICE, BUNDLE], check=False, capture_output=True)
    restored = disk.with_name('rootfs.benchmark-next.ext4')
    subprocess.run(['cp', '-c', str(baseline_disk), str(restored)], check=True)
    os.replace(restored, disk)
    if digest(disk) != identity['diskSHA256']:
        raise SystemExit('Restored disk does not match baseline')
    prefix = OUT / f'{number:02d}-enabled-{enabled}'
    env = dict(os.environ, PINECONE_SIMULATOR_UDID=DEVICE,
               PINECONE_PROFILE_TIMEOUT_SECONDS='240',
               PINECONE_PROFILE_INTERACTION_TRACE='1',
               SIMCTL_CHILD_PINECONE_THREADED_PROTOTYPE=str(enabled))
    started = time.monotonic()
    samples = []
    print(f'RUN {number}/6 prototype={enabled}', flush=True)
    with prefix.with_suffix('.json').open('w') as stdout, prefix.with_suffix('.stderr').open('w') as stderr:
        proc = subprocess.Popen(['bash', 'scripts/profile-pinecone-phosh.sh'], cwd=ROOT, env=env, stdout=stdout, stderr=stderr)
        while proc.poll() is None:
            samples.append({'elapsedSeconds': time.monotonic() - started, 'processes': processes()})
            time.sleep(1)
    exit_code = proc.returncode
    for name in ['pinecone-performance.log', 'pinecone-uart.log']:
        if (cache / name).exists():
            prefix.with_suffix('.' + name).write_bytes((cache / name).read_bytes())
    prefix.with_suffix('.samples.json').write_text(json.dumps(samples))
    result = {'run': number, 'enabled': enabled, 'exitCode': exit_code}
    if exit_code == 0:
        metrics = json.loads(prefix.with_suffix('.json').read_text())
        result['elapsedMilliseconds'] = metrics['elapsedMilliseconds']
        result['prototype'] = metrics.get('threadedPrototypePrimary')
        result['readyExecution'] = metrics['executionAtMilestones']['interactiveWorkloadReady']
        last = processes()
        result['processAtReady'] = last
        result['peakSampledRSSKiB'] = max((p['rssKiB'] for s in samples for p in s['processes']), default=0)
        # Fixed post-readiness idle window; not an animation or touch benchmark.
        idle_start = time.monotonic()
        time.sleep(10)
        end = processes()
        idle_duration = time.monotonic() - idle_start
        result['processAfterTenSecondsIdle'] = end
        if len(last) == len(end) == 1 and last[0]['pid'] == end[0]['pid']:
            result['idleCPUPercent'] = 100 * (end[0]['cpuSeconds'] - last[0]['cpuSeconds']) / idle_duration
    result['diskSHA256Before'] = identity['diskSHA256']
    results.append(result)
    (OUT / 'summary.json').write_text(json.dumps(results, indent=2))
    print(json.dumps(result), flush=True)
    if exit_code != 0:
        raise SystemExit('Benchmark failed; stopping comparison')
print(f'Evidence: {OUT}', flush=True)
